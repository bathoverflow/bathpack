public class SRPN {
    public static void main(String[] args) {
	Foo foo = new Foo();
	foo.bar();
    }
}
