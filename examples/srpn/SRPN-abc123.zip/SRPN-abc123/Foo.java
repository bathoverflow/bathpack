public class Foo {
    public Foo() {
	
    }

    public void bar() {
	
    }
}
